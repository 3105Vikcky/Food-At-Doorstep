document.addEventListener('DOMContentLoaded', function () {
    loadCategories();
    loadSpecialThali();

    document.getElementById('searchBtn').addEventListener('click', searchFood);
});

//Load food Categories
function loadCategories() {
    // Categories
    const categories = ['Special Thali', 'Indian Food', 'Non-Veg', 'Burger', 'Street Food'];

    const categoryContainer = document.getElementById('foodCategories');
    categoryContainer.innerHTML = '';

    categories.forEach(category => {
        const categoryDiv = document.createElement('div');
        categoryDiv.className = 'category';
        categoryDiv.textContent = category;
        categoryDiv.addEventListener('click', () => {
            filterFoodItems(category)

        });

        categoryContainer.appendChild(categoryDiv);
    });
}



//Filter food by Category
function filterFoodItems(category) {

    console.log(`Filtering food items by category: ${category}`);

    const categories = ['Special Thali', 'Indian Food', 'Non-Veg', 'Burger', 'Street Food'];

    // Here we would load only the items of the selected category
    if(category==categories[0]){
        loadSpecialThali(); 
    }
    else if(category==categories[1]){
        loadIndainFood(); 
    }
    else if(category==categories[2])
    {
        loadNonveg();
    }
    else if(category==categories[3])
    {
        loadBurger();
    }
    else if(category==categories[4])
    {
        loadStreetFood();
    }
    
}


// Show food Item
function displayFoodItems(category) {
    categoriesDiv.innerHTML = '';
    const categoryData = foodData.find(cat => cat.category.toLowerCase() === category.toLowerCase());

    if (categoryData) {
        categoryData.items.forEach(item => {
            const foodItemDiv = document.createElement('div');
            foodItemDiv.classList.add('food-item');

            foodItemDiv.innerHTML = `
                <img src="${item.image}" alt="${item.name}">
                <h3>${item.name}</h3>
                <p>Price: Rs${item.price}</p>
                <button onclick="addToCart(${item.id}, '${category}')">Buy</button>
            `;

            categoriesDiv.appendChild(foodItemDiv);
        });
    } else {
        categoriesDiv.innerHTML = '<p>No items found in this category.</p>';
    }
}



//Search Food by food name
function searchFood() {
    const searchTerm = searchInput.value.trim();
    
    displayFoodItems(searchTerm);
}




//load only special food items
function loadSpecialThali() {

    const specialThali = [
        { id: 1, name: 'Goa Thali', category: 'Special Thali', price: 200, img: 'Images/SpecialThali/GoaThali.jpg' },
        { id: 2, name: 'Gujrati Thali', category: 'Special Thali', price: 220, img: 'Images/SpecialThali/GujaratiThali.jpg' },
        { id: 3, name: 'Kashmiri Thali', category: 'Special Thali', price: 320, img: 'Images/SpecialThali/KashmiriThali.jpg' },
        { id: 4, name: 'Khandesi Thali Thali', category: 'Special Thali', price: 190, img: 'Images/SpecialThali/KhandesiThali.jpg' },
        { id: 5, name: 'Kolhapuri Thali', category: 'Special Thali', price: 220, img: 'Images/SpecialThali/KolhapuriThali.jpg' },
        { id: 6, name: 'Maharaja Thali', category: 'Special Thali', price: 300, img: 'Images/SpecialThali/MaharajaThali.jpg' },
        { id: 7, name: 'Maharashtrian Thali', category: 'Special Thali', price: 250, img: 'Images/SpecialThali/MaharashtrianThali.jpg' },
        { id: 8, name: 'SouthIndian Thali', category: 'Special Thali', price: 120, img: 'Images/SpecialThali/SouthIndianThali.jpg' },
    ];

    const foodContainer = document.getElementById('foodItems');
    foodContainer.innerHTML = '';

    specialThali.forEach(item => {
        const foodDiv = document.createElement('div');
        foodDiv.className = 'food-item';

        var addtocart=(item.id,item.name,item.category,item.price);
        foodDiv.innerHTML = `
            <img src="${item.img}" alt="${item.name}">
            <div class="details">
                <h3>${item.name}</h3>
                <p class="price">₹${item.price}</p>
            </div>
            <button onclick="addToCart(${addtocart})">Buy</button>
        `;

        foodContainer.appendChild(foodDiv);
    });

}


//load Indian Food

function loadIndainFood() {

    const IndianFood = [
        { id: 9, name: 'Appam', category: 'Indian Food', price: 70, img: 'Images/IndianFood/Appam.jpg' },
        { id: 10, name: 'Chapati Bhaaji', category: 'Indian Food', price: 70, img: 'Images/IndianFood/ChapatiBhaaji.jpg' },
        { id: 11, name: 'Daal Batti', category: 'Indian Food', price: 80, img: 'Images/IndianFood/DaalBatti.jpg' },
        { id: 12, name: 'IdliDosa', category: 'Indian Food', price: 50, img: 'Images/IndianFood/IdliDosa.jpg' },
        { id: 13, name: 'Khichadi', category: 'Indian Food', price: 60, img: 'Images/IndianFood/Khichdi.jpg' },
        { id: 14, name: 'Litti Choka', category: 'Indian Food', price: 80, img: 'Images/IndianFood/LittiChoka.jpg' },
        { id: 15, name: 'Medu Vada', category: 'Indian Food', price: 50, img: 'Images/IndianFood/MeduVada.jpg' },
        { id: 16, name: 'Paneer Makhani', category: 'Indian Food', price: 100, img: 'Images/IndianFood/PaneerMakhani.jpg' },
        { id: 17, name: 'Pulav', category: 'Indian Food', price: 40, img: 'Images/IndianFood/Pulav.jpg' },
        { id: 18, name: 'Puran Poli', category: 'Indian Food', price: 90, img: 'Images/IndianFood/PuranPoli.jpg' },
        { id: 19, name: 'Puri Bhaji', category: 'Indian Food', price: 60, img: 'Images/IndianFood/PuriBhaji.jpg' },
        { id: 20, name: 'Sarso Ka Saag', category: 'Indian Food', price: 50, img: 'Images/IndianFood/SarsoKaSaag.jpg' },
        { id: 21, name: 'Veg Paneer', category: 'Indian Food', price: 80, img: 'Images/IndianFood/VegPaneer.jpg' },
        { id: 22, name: 'Zunka Bhaakar', category: 'Indian Food', price: 40, img: 'Images/IndianFood/ZunkaBhaakar.jpg' },
    ];

    const foodContainer = document.getElementById('foodItems');
    foodContainer.innerHTML = '';

    IndianFood.forEach(item => {
        const foodDiv = document.createElement('div');
        foodDiv.className = 'food-item';

        foodDiv.innerHTML = `
            <img src="${item.img}" alt="${item.name}">
            <div class="details">
                <h3>${item.name}</h3>
                <p class="price">₹${item.price}</p>
            </div>
            <button onclick="addToCart(${item.id})">Buy</button>
        `;

        foodContainer.appendChild(foodDiv);
    });

}


//Load Non-veg dynamically

function loadNonveg() {

    const NonVEG = [
        { id: 23, name: 'Anda Biryani', category: 'Non-Veg', price: 120, img: 'Images/Non-Veg/AndaBiryani.jpg' },
        { id: 24, name: 'Chicken Leg', category: 'Non-Veg', price: 160, img: 'Images/Non-Veg/ChickenLeg.jpg' },
        { id: 25, name: 'Dum Biryani', category: 'Non-Veg', price: 130, img: 'Images/Non-Veg/DumBiryani.jpg' },
        { id: 26, name: 'Chiken Tandoori', category: 'Non-Veg', price: 160, img: 'Images/Non-Veg/ChickenTandoori.jpg' },
        { id: 27, name: 'Hydrabadi Biryani', category: 'Non-Veg', price: 120, img: 'Images/Non-Veg/HyderabadiBiryani.jpg' },
        { id: 28, name: 'Kabab', category: 'Non-Veg', price: 300, img: 'Images/Non-Veg/Kabab.jpg' },
        { id: 29, name: 'Mutton Hundi', category: 'Non-Veg', price: 480, img: 'Images/Non-Veg/MuttonHandi.jpg' },
        { id: 30, name: 'Mutton Ran', category: 'Non-Veg', price: 500, img: 'Images/Non-Veg/MuttonRan.jpg' },
        { id: 31, name: 'Fish Curry', category: 'Non-Veg', price: 180, img: 'Images/Non-Veg/FishCurry.jpg' },
       
    ];

    const foodContainer = document.getElementById('foodItems');
    foodContainer.innerHTML = '';

    NonVEG.forEach(item => {
        const foodDiv = document.createElement('div');
        foodDiv.className = 'food-item';

        foodDiv.innerHTML = `
            <img src="${item.img}" alt="${item.name}">
            <div class="details">
                <h3>${item.name}</h3>
                <p class="price">₹${item.price}</p>
            </div>
            <button onclick="addToCart(${item.id})">Buy</button>
        `;

        foodContainer.appendChild(foodDiv);
    });

}

//Load Burger dynamically

function loadBurger() {

    const Burger = [
        { id: 32, name: 'Bun Burger', category: 'Burger', price: 80, img: 'Images/Burger/BunBurger.jpg' },
        { id: 33, name: 'Charcol Burger', category: 'Burger', price: 160, img: 'Images/Burger/CharcolBureger.jpg' },
        { id: 34, name: 'Cheez Burger', category: 'Burger', price: 130, img: 'Images/Burger/CheezBurger.jpg' },
        { id: 35, name: 'Chiken Burger', category: 'Burger', price: 160, img: 'Images/Burger/ChikenBurger.jpg' },
        { id: 36, name: 'Cream Burger', category: 'Burger', price: 120, img: 'Images/Burger/CreamBurger.jpg' },
        { id: 37, name: 'King Burger', category: 'Burger', price:140, img: 'Images/Burger/KingBureger.jpg' },
        { id: 38, name: 'Regular Burger', category: 'Burger', price: 70, img: 'Images/Burger/RegularBurger.jpg' },
        { id: 39, name: 'Veg Burger', category: 'Burger', price: 90, img: 'Images/Burger/VegBurger.jpg' },
               
    ];

    const foodContainer = document.getElementById('foodItems');
    foodContainer.innerHTML = '';

    Burger.forEach(item => {
        const foodDiv = document.createElement('div');
        foodDiv.className = 'food-item';

        foodDiv.innerHTML = `
            <img src="${item.img}" alt="${item.name}">
            <div class="details">
                <h3>${item.name}</h3>
                <p class="price">₹${item.price}</p>
            </div>
            <button onclick="addToCart(${item.id})">Buy</button>
        `;

        foodContainer.appendChild(foodDiv);
    });

}



//Load StreetFood dynamically

function loadStreetFood() {

    const StreetFood = [
        { id: 40, name: 'Bhajia', category: 'StreetFood', price: 50, img: 'Images/StreetFood/Bhajia.jpg' },
        { id: 41, name: 'Bhel', category: 'StreetFood', price: 60, img: 'Images/StreetFood/Bhel.jpg' },
        { id: 42, name: 'Chole Bhature', category: 'StreetFood', price: 60, img: 'Images/StreetFood/CholeBhature.jpg' },
        { id: 43, name: 'Dahi Vada', category: 'StreetFood', price: 60, img: 'Images/StreetFood/DahiVada.jpg' },
        { id: 44, name: 'Dhokla', category: 'StreetFood', price: 30, img: 'Images/StreetFood/Dhokla.jpg' },
        { id: 45, name: 'Jalebi', category: 'StreetFood', price:40, img: 'Images/StreetFood/Jalebi.jpg' },
        { id: 46, name: 'Kachori', category: 'StreetFood', price: 20, img: 'Images/StreetFood/Kachori.jpg' },
        { id: 47, name: 'Momos', category: 'StreetFood', price: 80, img: 'Images/StreetFood/Momos.jpg' },
        { id: 47, name: 'Paneer Roll', category: 'StreetFood', price: 90, img: 'Images/StreetFood/PaneerRoll.jpg' },
        { id: 47, name: 'Pani Puri', category: 'StreetFood', price: 20, img: 'Images/StreetFood/PaniPuri.jpg' },
        { id: 47, name: 'Papda', category: 'StreetFood', price: 10, img: 'Images/StreetFood/Papda.jpg' },
               
    ];

    const foodContainer = document.getElementById('foodItems');
    foodContainer.innerHTML = '';

    StreetFood.forEach(item => {
        const foodDiv = document.createElement('div');
        foodDiv.className = 'food-item';

        foodDiv.innerHTML = `
            <img src="${item.img}" alt="${item.name}">
            <div class="details">
                <h3>${item.name}</h3>
                <p class="price">₹${item.price}</p>
            </div>
            <button onclick="addToCart(${item.id})">Buy</button>
        `;

        foodContainer.appendChild(foodDiv);
    });

}



//All Food Items
function loadFoodCategories()
{

}


//Add to cart
function addToCart(item) 
{
    const addtocart=[item.id, item.price, item.category, item.price, item.img];
    addtocart.forEach(item => {
    const foodDiv = document.createElement('div');
        foodDiv.className = 'food-item';

        foodDiv.innerHTML = `
            <img src="${item.img}" alt="${item.name}">
            <div class="details">
                <h3>${item.name}</h3>
                <p class="price">₹${item.price}</p>
            </div>
        
        `;

        foodContainer.appendChild(foodDiv);
    });
    // Here we would add the item to the user's cart
}